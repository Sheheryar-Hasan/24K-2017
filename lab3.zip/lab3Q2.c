#include <stdio.h>
int main(){
	int x;
	int y;
	int z;
	printf("please enter a number x:");
	scanf("%d", &x);
	printf("please enter a 2nd number y:");
	scanf("%d", &y);
	z = x;
	x = y;
	printf("value of x is=%d\n", x);
	printf("value of y is=%d", z);
	
	return 0;
}
