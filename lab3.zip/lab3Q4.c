#include <stdio.h>
int main(){
	int fcost1 = 118;
	int fcost2 = 123;
	int distance = 1207;
	int favg;
	int totalcost;
	int going;
	int returning;
	printf("enter your cars average fuel consumption(only positive numbers allowed)=");
	scanf("%d", &favg);
	totalcost= ((distance/favg) * fcost1) + ((distance/favg)*fcost2);
	going=(distance/favg) * fcost1;
	returning=(distance/favg)*fcost2;
	printf("the total cost of going is=%d\n", going);
	printf ("the total cost of returning is=%d\n", returning);
	printf("your total cost for this journey is=%d", totalcost);
	
	return 0;

}
