#include <stdio.h>
int main(){
	float sal;
	float taxrate;
	float tax;
	float netsal;
	printf("please enter your salary=");
	scanf("%f", &sal);
	printf("please enter taxrate=");
	scanf("%f", &taxrate);
	tax = (taxrate/100)*sal;
	netsal = sal-tax;
	printf("your taxes are=%f\n", tax);
	printf("your remaining salary after tax cuts is=%f", netsal);
	
	return 0;
}

