#include <stdio.h>
int main(){
	float km,mile;
	printf("please enter value in kilometers=");
	scanf("%f", &km);
	mile= km*0.62137;
	printf("converting kilometers to miles gives us=%f", mile);
	
	return 0;
}
