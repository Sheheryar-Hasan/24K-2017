#include <stdio.h>
int main(){
	float l,w,perimeter;
	printf("please enter length and width of the rectangle=");
		scanf("%f", &l);
		scanf("%f",&w);
    	perimeter= (2*l)+(2*w);
	printf("perimeter of the rectangle of given measurements is=%f", perimeter);
	
	return 0;
}
