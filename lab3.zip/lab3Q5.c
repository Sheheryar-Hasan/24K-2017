#include <stdio.h>
int main(){
	
	int principal;
	int rate;
	int time;
	int interest;
	
	printf("please enter your principal amount(must be between Rs.100-Rs.1000000)=");
	scanf("%d", &principal);
	
	printf("please enter rate of interest(only between 5 and 10 percent):");
	scanf("%d", &rate);
	
	printf("please enter time in years:");
	scanf("%d", &time);
	
	interest = (principal * rate * time) / 100;
	printf("your simple interest is=%d\n", interest);
	
	return 0;
}
