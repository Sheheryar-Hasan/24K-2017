#include <stdio.h>
int main(){ 
	
	float a,b,x,y,float;
	printf("enter x and y coordinates of first point=");
	scanf("%f", &a);
	scanf("%f", &b);
	printf("enter x and y coordinates of 2nd point=");
	scanf("%f", &x);
	scanf("%f", &y);
	slope= (b-y)/(a-x);
	printf("gradient of the 2 points is=%.3f", slope);

    return 0;	
}
