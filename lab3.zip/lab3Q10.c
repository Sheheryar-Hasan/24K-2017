#include <stdio.h>
int main(){
	
	float w,h,bmi;
	printf("please enter weight in kilograms=");
	scanf("%f", &w);
	printf("please enter subjects height in meters=");
	scanf("%f", &h);
	bmi=w/(h*h);
	printf("BMI index of subject is=%f", bmi);
	
	return 0;
}
